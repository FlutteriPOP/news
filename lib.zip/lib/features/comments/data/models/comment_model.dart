import 'package:json_annotation/json_annotation.dart';

import '../../../../core/utils/time_formatter.dart';
import '../../domain/entities/comment.dart';

part 'comment_model.g.dart';

@JsonSerializable()
class CommentModel {
  const CommentModel({
    required this.id,
    required this.time,
    @JsonKey(name: 'by') this.author,
    this.text = '',
    this.kids = const [],
    this.parent,
  });

  factory CommentModel.fromJson(Map<String, dynamic> json) =>
      _$CommentModelFromJson(json);
  final int id;
  final int time;
  @JsonKey(name: 'by')
  final String? author;
  final String text;
  final List<int> kids;
  final int? parent;

  Map<String, dynamic> toJson() => _$CommentModelToJson(this);

  Comment toEntity() {
    return Comment(
      id: id,
      author: author ?? '[deleted]',
      text: text,
      time: DateTimeUtils.fromUnix(time),
      kids: kids,
      parent: parent ?? 0,
    );
  }
}

import 'package:dartz/dartz.dart';

import '../../../../core/error/error_handler.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/comment.dart';
import '../../domain/repositories/comments_repository.dart';
import '../datasources/comments_remote_datasource.dart';

class CommentsRepositoryImpl with ErrorHandler implements CommentsRepository {
  CommentsRepositoryImpl(this.remoteDataSource);
  final CommentsRemoteDataSource remoteDataSource;

  @override
  Future<Either<Failure, Comment>> getCommentById(int id) => handleErrors(() async {
    final model = await remoteDataSource.getCommentById(id);
    return model.toEntity();
  });

  @override
  Future<Either<Failure, List<Comment>>> getCommentsByIds(List<int> ids) =>
      handleErrors(() async {
        final results = await Future.wait(
          ids.map((id) => remoteDataSource.getCommentById(id)),
        );
        return results.map((model) => model.toEntity()).toList();
      });
}

import 'package:get/get.dart';

import '../../../../core/network/dio_client.dart';
import '../../data/datasources/comments_remote_datasource.dart';
import '../../data/repository_impl/comments_repository_impl.dart';
import '../../domain/repositories/comments_repository.dart';

class CommentsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<CommentsRemoteDataSource>(
      () => CommentsRemoteDataSourceImpl(Get.find<DioClient>().dio),
    );
    Get.lazyPut<CommentsRepository>(
      () => CommentsRepositoryImpl(Get.find<CommentsRemoteDataSource>()),
    );
  }
}

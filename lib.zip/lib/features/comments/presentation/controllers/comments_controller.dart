import 'package:get/get.dart';

import '../../../../core/controllers/base_controller.dart';
import '../../domain/entities/comment.dart';
import '../../domain/repositories/comments_repository.dart';

class CommentsController extends BaseController {
  CommentsController({
    required this.repository,
    required this.initialCommentIds,
  });
  final CommentsRepository repository;
  final List<int> initialCommentIds;

  final RxList<Comment> comments = <Comment>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchComments();
  }

  Future<void> fetchComments() async {
    if (initialCommentIds.isEmpty) return;

    showLoading();
    clearError();
    try {
      final fetchedComments = await Future.wait(
        initialCommentIds.map((id) => _fetchRecursive(id)),
      );
      comments.value = fetchedComments;
    } catch (e) {
      setError(e.toString());
    } finally {
      hideLoading();
    }
  }

  Future<Comment> _fetchRecursive(int id) async {
    final result = await repository.getCommentById(id);
    return await result.fold((failure) => throw Exception(failure.message), (
      comment,
    ) async {
      if (comment.kids.isEmpty) return comment;
      final replies = await Future.wait(
        comment.kids.map((kidId) => _fetchRecursive(kidId)),
      );
      return comment.copyWith(replies: replies);
    });
  }
}

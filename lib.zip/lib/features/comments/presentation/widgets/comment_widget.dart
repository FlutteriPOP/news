import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:shadcn_ui/shadcn_ui.dart';

import '../../../../../core/utils/time_formatter.dart';
import '../../domain/entities/comment.dart';

class CommentWidget extends StatelessWidget {
  const CommentWidget({required this.comment, super.key, this.depth = 0});
  final Comment comment;
  final int depth;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: EdgeInsets.only(left: depth == 0 ? 0 : 16, right: 16, bottom: 16),
      child: ShadCard(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with Author and Time
              Row(
                children: [
                  // Avatar
                  ShadAvatar(
                    comment.author.isNotEmpty
                        ? comment.author[0].toUpperCase()
                        : 'A',
                  ),
                  const SizedBox(width: 12),

                  // Author Name
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          comment.author,
                          style: theme.textTheme.bodyMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                            color: theme.colorScheme.onSurface,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          TimeFormatter.formatRelative(comment.time),
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.outline,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              // Comment Content
              Html(
                data: comment.text,
                style: {
                  'body': Style(
                    margin: Margins.zero,
                    padding: HtmlPaddings.zero,
                    fontSize: FontSize(
                      theme.textTheme.bodyMedium?.fontSize ?? 14,
                    ),
                    lineHeight: const LineHeight(1.5),
                    color: theme.colorScheme.onSurface,
                  ),
                  'p': Style(margin: Margins.only(bottom: 8)),
                  'code': Style(
                    backgroundColor: Colors.grey[200],
                    padding: HtmlPaddings.all(4),
                    fontFamily: 'monospace',
                  ),
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

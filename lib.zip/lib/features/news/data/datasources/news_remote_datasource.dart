import 'package:dio/dio.dart';

import '../models/story_model.dart';

abstract class NewsRemoteDataSource {
  Future<List<int>> getStoriesIds(String type);
  Future<StoryModel> getStoryById(int id);
}

class NewsRemoteDataSourceImpl implements NewsRemoteDataSource {
  NewsRemoteDataSourceImpl(this.client);
  final Dio client;

  @override
  Future<List<int>> getStoriesIds(String type) async {
    final response = await client.get('$type.json');
    if (response.statusCode == 200 && response.data != null) {
      return List<int>.from(response.data);
    } else {
      throw Exception('Invalid response for $type: ${response.statusCode}');
    }
  }

  @override
  Future<StoryModel> getStoryById(int id) async {
    final response = await client.get('item/$id.json');
    if (response.statusCode == 200 && response.data != null) {
      return StoryModel.fromJson(response.data);
    } else {
      throw Exception('Invalid story response: ${response.statusCode}');
    }
  }
}

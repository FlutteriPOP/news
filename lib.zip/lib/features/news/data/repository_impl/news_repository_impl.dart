import 'package:dartz/dartz.dart';

import '../../../../core/error/error_handler.dart';
import '../../../../core/error/failures.dart';
import '../../domain/entities/story.dart';
import '../../domain/entities/story_type.dart';
import '../../domain/repositories/news_repository.dart';
import '../datasources/news_remote_datasource.dart';

class NewsRepositoryImpl with ErrorHandler implements NewsRepository {
  NewsRepositoryImpl(this.remoteDataSource);
  final NewsRemoteDataSource remoteDataSource;

  @override
  Future<Either<Failure, List<int>>> getStoriesIds(StoryType type) =>
      handleErrors(() => remoteDataSource.getStoriesIds(type.apiPath));

  @override
  Future<Either<Failure, Story>> getStoryById(int id) => handleErrors(() async {
    final model = await remoteDataSource.getStoryById(id);
    return model.toEntity();
  });
}

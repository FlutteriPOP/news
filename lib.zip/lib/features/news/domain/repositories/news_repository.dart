import 'package:dartz/dartz.dart';
import '../../../../core/error/failures.dart';
import '../entities/story.dart';
import '../entities/story_type.dart';

abstract class NewsRepository {
  Future<Either<Failure, List<int>>> getStoriesIds(StoryType type);
  Future<Either<Failure, Story>> getStoryById(int id);
}

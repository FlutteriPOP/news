import 'package:get/get.dart';

import '../../../../core/controllers/base_controller.dart';
import '../../domain/entities/story.dart';
import '../../domain/entities/story_type.dart';
import '../../domain/repositories/news_repository.dart';

class NewsController extends BaseController {
  NewsController({required this.repository});
  final NewsRepository repository;

  final RxList<Story> stories = <Story>[].obs;
  final Rx<StoryType> currentStoryType = StoryType.top.obs;
  final RxBool isLoadingMore = false.obs;

  int _currentIndex = 0;
  static const int _pageSize = 20;
  List<int> _allIds = [];

  @override
  void onInit() {
    super.onInit();
    fetchStories();
  }

  Future<void> fetchStories() async {
    showLoading();
    clearError();
    _currentIndex = 0;
    try {
      final result = await repository.getStoriesIds(currentStoryType.value);
      result.fold((failure) => setError(failure.message), (ids) async {
        _allIds = ids;
        stories.value = await _fetchNextBatch();
      });
    } catch (e) {
      setError(e.toString());
    } finally {
      hideLoading();
    }
  }

  Future<List<Story>> _fetchNextBatch() async {
    final nextIds = _allIds.skip(_currentIndex).take(_pageSize).toList();
    _currentIndex += _pageSize;

    final results = await Future.wait(
      nextIds.map((id) => repository.getStoryById(id)),
    );

    final List<Story> batch = [];
    for (final result in results) {
      result.fold((_) => null, (story) => batch.add(story));
    }
    return batch;
  }

  Future<void> fetchMore() async {
    if (isLoadingMore.value || _currentIndex >= _allIds.length) {
      return;
    }

    isLoadingMore.value = true;
    try {
      final nextBatch = await _fetchNextBatch();
      stories.addAll(nextBatch);
    } catch (e) {
      setError(e.toString());
    } finally {
      isLoadingMore.value = false;
    }
  }

  Future<void> refreshStories() async {
    await fetchStories();
  }

  Future<void> changeStoryType(StoryType newType) async {
    if (currentStoryType.value == newType) return;
    currentStoryType.value = newType;
    await fetchStories();
  }
}

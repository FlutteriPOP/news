import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shadcn_ui/shadcn_ui.dart';

import '../../../../core/utils/time_formatter.dart';
import '../../../../core/utils/url_launcher_utils.dart';
import '../../../../core/widgets/error_view.dart';
import '../../../comments/domain/repositories/comments_repository.dart';
import '../../../comments/presentation/controllers/comments_controller.dart';
import '../../../comments/presentation/widgets/comment_widget.dart';
import '../../domain/entities/story.dart';

class NewsDetailScreen extends StatefulWidget {
  const NewsDetailScreen({required this.story, super.key});
  final Story story;

  @override
  State<NewsDetailScreen> createState() => _NewsDetailScreenState();
}

class _NewsDetailScreenState extends State<NewsDetailScreen> {
  late CommentsController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.put(
      CommentsController(
        repository: Get.find<CommentsRepository>(),
        initialCommentIds: widget.story.kids,
      ),
      tag: widget.story.id.toString(),
    );
  }

  @override
  void dispose() {
    Get.delete<CommentsController>(tag: widget.story.id.toString());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 120,
            pinned: true,
            backgroundColor: Theme.of(context).colorScheme.surface,
            surfaceTintColor: Colors.transparent,
            flexibleSpace: FlexibleSpaceBar(
              title: Text(
                widget.story.title,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              titlePadding: const EdgeInsets.only(
                left: 16,
                bottom: 16,
                right: 16,
              ),
            ),
            actions: [
              if (widget.story.url != null)
                ShadButton.ghost(
                  onPressed: () => UrlLauncherUtils.launch(widget.story.url!),
                  child: const Icon(Icons.open_in_new),
                ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: ShadCard(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          ShadBadge(
                            child: Text('${widget.story.score} points'),
                          ),
                          ShadBadge.outline(child: Text(widget.story.author)),
                          ShadBadge.secondary(
                            child: Text(
                              '${widget.story.commentsCount} comments',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          const Icon(Icons.schedule, size: 16),
                          const SizedBox(width: 6),
                          Text(
                            'Posted ${TimeFormatter.formatRelative(widget.story.time)}',
                            style: Theme.of(context).textTheme.bodySmall
                                ?.copyWith(
                                  color: Theme.of(context).colorScheme.outline,
                                ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(
                    Icons.comment,
                    color: Theme.of(context).colorScheme.primary,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    'Comments',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                  ),
                  const Spacer(),
                  ShadBadge.outline(
                    child: Text(widget.story.commentsCount.toString()),
                  ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.only(left: 16, right: 16, bottom: 16),
            sliver: Obx(() {
              if (controller.isLoading.value) {
                return const SliverFillRemaining(
                  child: Center(child: CircularProgressIndicator()),
                );
              }

              if (controller.errorMessage.isNotEmpty) {
                return SliverFillRemaining(
                  child: ErrorView(
                    message: controller.errorMessage.value,
                    onRetry: () => controller.fetchComments(),
                  ),
                );
              }

              return SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) =>
                      CommentWidget(comment: controller.comments[index]),
                  childCount: controller.comments.length,
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../core/widgets/error_view.dart';
import '../../domain/entities/story.dart';
import '../../domain/entities/story_type.dart';
import '../controllers/news_controller.dart';
import '../widgets/story_card.dart';

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key});

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final NewsController controller = Get.find<NewsController>();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: StoryType.values.length,
      vsync: this,
    );

    _tabController.addListener(() {
      if (!_tabController.indexIsChanging) {
        final newType = StoryType.values[_tabController.index];
        controller.changeStoryType(newType);
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surface,
              border: Border(
                bottom: BorderSide(
                  color: Theme.of(
                    context,
                  ).colorScheme.outline.withValues(alpha: 0.2),
                ),
              ),
            ),
            child: SafeArea(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'WHACK',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 16),
                  TabBar(
                    controller: _tabController,
                    isScrollable: true,
                    tabs: StoryType.values.map((type) {
                      return Tab(
                        text: type.displayName,
                        icon: Icon(_getIconForType(type)),
                      );
                    }).toList(),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: StoryType.values.map((type) {
                return _buildStoriesList();
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStoriesList() {
    return Obx(() {
      if (controller.isLoading.value && controller.stories.isEmpty) {
        return const Center(child: CircularProgressIndicator());
      }

      if (controller.errorMessage.isNotEmpty && controller.stories.isEmpty) {
        return ErrorView(
          message: controller.errorMessage.value,
          onRetry: () => controller.refreshStories(),
        );
      }

      return RefreshIndicator(
        onRefresh: () => controller.refreshStories(),
        child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: controller.stories.length + 1,
          itemBuilder: (context, index) {
            if (index == controller.stories.length) {
              if (controller.stories.isEmpty) return const SizedBox.shrink();
              controller.fetchMore();
              return const Center(
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: CircularProgressIndicator(),
                ),
              );
            }
            final story = controller.stories[index];
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: StoryCard(story: story),
            );
          },
        ),
      );
    });
  }

  IconData _getIconForType(StoryType type) {
    switch (type) {
      case StoryType.top:
        return Icons.trending_up;
      case StoryType.new_:
        return Icons.fiber_new;
      case StoryType.best:
        return Icons.star;
      case StoryType.ask:
        return Icons.help_outline;
      case StoryType.show:
        return Icons.visibility;
      case StoryType.jobs:
        return Icons.work;
    }
  }
}

class StorySearchDelegate extends SearchDelegate<Story?> {
  final NewsController controller = Get.find<NewsController>();

  @override
  List<Widget>? buildActions(BuildContext context) {
    return [
      IconButton(
        icon: const Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      ),
    ];
  }

  @override
  Widget? buildLeading(BuildContext context) {
    return IconButton(
      icon: const Icon(Icons.arrow_back),
      onPressed: () {
        close(context, null);
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return _buildSearchResults();
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    return _buildSearchResults();
  }

  Widget _buildSearchResults() {
    if (query.isEmpty) {
      return const Center(child: Text('Enter a search term'));
    }

    final filteredStories = controller.stories.where((story) {
      final title = story.title.toLowerCase();
      final author = story.author.toLowerCase();
      final searchQuery = query.toLowerCase();

      return title.contains(searchQuery) || author.contains(searchQuery);
    }).toList();

    if (filteredStories.isEmpty) {
      return const Center(child: Text('No results found'));
    }

    return ListView.builder(
      itemCount: filteredStories.length,
      itemBuilder: (context, index) {
        final story = filteredStories[index];
        return StoryCard(story: story);
      },
    );
  }
}
